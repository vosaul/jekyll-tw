---
title: Kraken
logo: /assets/images/c7.png
description: Kraken is a crypto exchange for everyone.
sites:
- link: https://www.kraken.com/
  icon: link-45deg.svg
- link: https://twitter.com/krakenfx
  icon: twitter.svg
---