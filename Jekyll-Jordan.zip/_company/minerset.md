---
title: Minerset
logo: /assets/images/c2.png
description: |
  Minerset team has been distributing mining hardware and accessories from China for many years
sites:
- link: https://minerset.com/
  icon: link-45deg.svg
- link: #
  icon: twitter.svg
---

Minerset team has been distributing mining hardware and accessories from China for many years.