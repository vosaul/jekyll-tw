---
title: BTC Inc
logo: /assets/images/c6.png
description: Support Organization for the promotion and education of the Bitcoin community in all things bitcoin.
sites:
- link: https://b.tc/about
  icon: link-45deg.svg
- link: https://twitter.com/_btcinc
  icon: twitter.svg
---