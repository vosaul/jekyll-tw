---
title: Braiins
logo: /assets/images/c8.png
description: Braiins creates bitcoin mining tools that includes hardware and software. The company also oprates an industry leading bitcoin mining pool called Slush Pool.
sites:
- link: https://braiins.com/
  icon: link-45deg.svg
- link: https://twitter.com/braiins_systems
  icon: twitter.svg
---