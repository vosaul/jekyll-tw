---
title: Senior Android Engineer
description: River Financial is hiring for a full time Senior Android Engineer since Dec 29, 2022. Apply today.
logo: /assets/images/c12.webp
date: 2022-12-29
location: Remote
type: Full Time
salary: 
category: Bitcoin Developer
---

## Job details

This role will involve the design, development, and maintenance of the Android app. Requires 5+ years experience in building mobile consumer applications using Kotlin or Java. Experience in GraphQL and Bitcoin is a plus.
