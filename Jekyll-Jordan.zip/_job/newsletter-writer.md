---
title: Part Time Newsletter Writer
description: Bitbo is hiring for a part time Part Time Newsletter Writer since Feb 08, 2023. Apply today.
logo: /assets/images/c5.webp
date: 2023-09-04
location: Remote
type: Part Time
salary: 
category: Analyst
---

## Job details

We're looking for a newsletter writer to write a once a month detailed overview of the Bitcoin and financial markets. Similar style would be Bitcoin Magazine Pro or Blockware.
